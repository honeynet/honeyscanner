# TAR Bomb for reasearch academic project

Please do not extract

- To create it:
1. dd if=/dev/zero of=sparse_file bs=1 count=0 seek=10T
2. tar -cf not_a_tar_bomb.tar sparse_file

- To extract:
1. tar -xf not_a_tar_bomb.tar

big one: "1Chow8Qh-bUb_LCqJzeTdN1PNmWlZ6kyi"
medium: "1GVPnsQIkyUJqEQFR3vYxmkbvM3B0uS4g"
small: "1Jc60r-D33DUF2TErY3qNhWpk0xFJB_kE"